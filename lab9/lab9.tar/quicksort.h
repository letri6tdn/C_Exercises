#ifndef QUICKSORT_H
#define QUICKSORT_H

int quicksort(int a[], int low, int high);
int split(int a[], int low, int high, int *count);

#endif