#ifndef HEAPSORT_H
#define HEAPSORT_H

int heapsort(int heap[], int n);

#endif