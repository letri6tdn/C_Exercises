#ifndef BUBBLESORT_H
#define BUBBLESORT_H

int bubblesort(int a[], int length);

#endif