#ifndef MERGESORT_H
#define MERGESORT_H

int mergesort(int a[], int left, int right);

#endif