#ifndef INSERTIONSORT_H
#define INSERTIONSORT_H

int insertionsort(int a[], int length);

#endif