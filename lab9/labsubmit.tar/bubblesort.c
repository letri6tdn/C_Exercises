#include "bubblesort.h"

int bubblesort(int a[], int length) {
	int counter = 0;

	for (int i = 0; i < length - 1; i++) { // count the number of comparisons made?
		counter++;
		if (a[i] > a[i+1]) { // swap a[i], a[i+1], re-set i
			int tmp = a[i];

			a[i] = a[i+1];
			a[i+1] = tmp;
			i = -1;
		}
	}

	return counter;
}