#include "mergesort.h"

int mergesort(int a[], int left, int right) {
	int count = 0;

	if (left >= right)
		return 0;
	
	int mid = (left + right) / 2;
	mergesort(a, left, mid);
	mergesort(a, mid + 1, right);

	// insert below C statements to merge two sorted subarrays:
	// v3: merging inside a[], but needs a lot of data moving
	for (int i = left; i <= mid; i++)
		for (int j = mid + 1; j <= right; j++) {
			count++;
			if (a[i] > a[j]) { // moving
				int temp = a[j];
				for (int k = j; k > i; k--){
					a[k] = a[k-1];
				}
				a[i] = temp;
				mid++; // keep the end of left subarray unchanged
			}
		}

	return count;
}