#ifndef SORTING_H
#define SORTING_H

#include <stdio.h>
#include <string.h>
#include "quicksort.h"
#include "mergesort.h"
#include "insertionsort.h"
#include "bubblesort.h"
#include "selectionsort.h"
#include "heapsort.h"

int main(int argc, char *argv[]);

#endif