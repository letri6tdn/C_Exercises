#ifndef SELECTIONSORT_H
#define SELECTIONSORT_H

int selectionsort(int array[], int n);

#endif