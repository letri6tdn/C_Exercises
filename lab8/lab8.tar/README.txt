project 3 and 5 page 375:
- I used Codeblock to create the project (since my PUTTY is having problems)
- I dont know how to compile the file using Windows but the .exe file is running inside the bin folder
- main.c is the source of the program
thank you for understanding
