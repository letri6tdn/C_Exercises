#define N 10

void quicksort(int a[], int low, int high);
int split(int a[], int low, int high);
