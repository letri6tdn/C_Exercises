run the main.c file
i coded it using codeblock